
<?php echo $__env->make('users_layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

    <?php echo $__env->yieldContent('content'); ?>


<?php echo $__env->make('users_layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\zing-credit-dashboard\resources\views/users_layout/base.blade.php ENDPATH**/ ?>